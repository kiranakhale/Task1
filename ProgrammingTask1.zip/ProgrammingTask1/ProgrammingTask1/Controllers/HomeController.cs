﻿using Microsoft.AspNetCore.Mvc;
using ProgrammingTask1.Models;
using System.Diagnostics;

namespace ProgrammingTask1.Controllers
{
    public class HomeController : Controller
    {
        // Url - /Home/Index/test
        public IActionResult Index(string name)
        {
            ViewBag.Name =  !string.IsNullOrEmpty (name) ? name : null;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
